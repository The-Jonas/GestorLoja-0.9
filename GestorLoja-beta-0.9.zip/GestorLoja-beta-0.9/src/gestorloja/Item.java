
package gestorloja;


public class Item {
    //atributos
    private int id;
    private String nome;
    private double preco;
    
    //construtores
    public Item(){}

    public Item(int id, String nome, double preco) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }
    
    
    //Geters e Seters

    public int getIdItem() {
        return id;
    }

    public void setIdItem(int id) {
        this.id = id;
    }

    public String getNomeItem() {
        return nome;
    }

    public void setNomeItem(String nome) {
        this.nome = nome;
    }

    public double getPrecoItem() {
        return preco;
    }

    public void setPrecoItem(double preco) {
        this.preco = preco;
    }
       
}
