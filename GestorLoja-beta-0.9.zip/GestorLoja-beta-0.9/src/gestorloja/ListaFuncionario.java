/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestorloja;
import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class ListaFuncionario {
         //referencia aos objetos associados
    private static final ArrayList<Funcionario> funcionarios = new ArrayList<>();

    public void inserirFuncionarios( Funcionario func ){
        funcionarios.add(func);    
    } 
    
    public void removerFuncionarios( Funcionario func ){
        funcionarios.remove(func);    
    }
    
    public ArrayList<Funcionario> getFuncionarios() {
        return funcionarios; 
    }
}
