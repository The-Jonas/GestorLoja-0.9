
package gestorloja;

import static gestorloja.Estoque.verificarPreco;
import java.util.ArrayList;

public class Caixa {
    private static final ArrayList<Integer[]> carrinho = new ArrayList<Integer[]>();
    private static double aPagar = 0;
    private static String cpfClienteCaixa;
    public static void addItem(int id, int quantidade){
        Integer[] array = {id, quantidade};
        carrinho.add(array);
    }
    public static void removeItemCarrinho(int id){
         for(int i = 0; i<carrinho.size(); i++){
             if((carrinho.get(i))[0] == id){
                 carrinho.remove(i);
                 break;
             }
         }
    }
    public static void limparCarrinho(){
        carrinho.clear();
    }
    public static void resetValor(){
        aPagar = 0;
    }
    public static double valorAPagar(){
        aPagar = 0;
        for(int i = 0; i<carrinho.size(); i++){
            aPagar = aPagar + verificarPreco((carrinho.get(i))[0]) * (carrinho.get(i))[1];
        }
        return aPagar;
    }
    public static ArrayList getCarrinho(){
        return carrinho;
    }

    public static String getCpfClienteCaixa() {
        return cpfClienteCaixa;
    }

    public static void setCpfClienteCaixa(String cpfCliente) {
        Caixa.cpfClienteCaixa = cpfCliente;
    }
    
}
