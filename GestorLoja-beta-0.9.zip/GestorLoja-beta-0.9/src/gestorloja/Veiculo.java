
package gestorloja;

public class Veiculo {
    
    //Atributos
    
    private String placa, modelo, cor, cpfDono, horarioDeEntrada;
    private int horarioEntradaCalculo, horarioSaidaCalculo;
    private double totalAPagar;
    private Cliente cliente;
    
    //private Cliente cliente;
    
    //Construtores

    public Veiculo() {
    }

    public Veiculo(String placa, String modelo, String cor, String idDono) {
        this.placa = placa;
        this.modelo = modelo;
        this.cor = cor;
        this.cpfDono = idDono; 
    }
    
    // Getters e Setters

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCpfDono() {
        return cpfDono;
    }
    
    public void setHorarioEntrada(String horario){
        this.horarioDeEntrada = horario;
    }
    
    public String getHorarioEntrada(){
        return horarioDeEntrada;
    }

    public void setIdDono(String CpfDono) {
        this.cpfDono = CpfDono;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getHorarioEntradaCalculo() {
        return horarioEntradaCalculo;
    }

    public void setHorarioEntradaCalculo(int horarioEntradaCalculo) {
        this.horarioEntradaCalculo = horarioEntradaCalculo;
    }

    public int getHorarioSaidaCalculo() {
        return horarioSaidaCalculo;
    }

    public void setHorarioSaidaCalculo(int horarioSaidaCalculo) {
        this.horarioSaidaCalculo = horarioSaidaCalculo;
    }

    public double getTotalAPagar() {
        return totalAPagar;
    }

    public void setTotalAPagar(double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }

    
}
