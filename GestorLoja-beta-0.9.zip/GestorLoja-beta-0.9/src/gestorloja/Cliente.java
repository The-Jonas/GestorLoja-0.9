/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestorloja;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class Cliente extends Pessoa{
    protected static int pontos;
    
    // Constructor
    public Cliente(){
    }
    public Cliente(String nome, String cpf){
       super(nome, cpf);
       Cliente.pontos = 0;
    }
    public static void cadastrarCliente(String nome, String cpf){
        Cliente cliente = new Cliente(nome, cpf);
    }
    
    // Geters e Seters
    public static int getPontos() {
        return pontos;
    }

    public void setPontos(int pts) {
        this.pontos = pts;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    

}