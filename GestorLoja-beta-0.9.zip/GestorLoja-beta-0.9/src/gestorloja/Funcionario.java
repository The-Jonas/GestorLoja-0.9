/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestorloja;

import java.util.ArrayList;

/**
 *
 * @author vinic
 */

public class Funcionario extends Pessoa{
    private String telefone;
    private String endereco;
    private String status;
    private String expediente;
  
    // Constructor
    public Funcionario(){
    }
    public Funcionario(String nome, String cpf, String telefone, String endereco, String status, String expediente){
       super(nome, cpf);
       this.telefone = telefone;
       this.endereco = endereco;
       this.status = status;
       this.expediente = expediente;
    }
    
    public static void cadastrarFuncionario(String nome, String cpf, String telefone, String endereco, String status, String expediente){
        Funcionario funcionario = new Funcionario(nome, cpf, telefone, endereco, status, expediente);
    }
    
    // Getters e Setters
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExpediente() {
        return expediente;
    }

    public void setExpediente(String expediente) {
        this.expediente = expediente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}