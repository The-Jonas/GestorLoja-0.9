package gestorloja;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
public class SalvarDados {
    //criar arquivos dos dados
    public static void criaArquivos () throws IOException {
        File arquivo;
        // Array com todos os nomes de arquivos disponíveis
        String[] nomesArquivos = {"produtos.txt", "clientes.txt", "funcionarios.txt", "veiculos.txt"};
        
        // Loop para criar todos os arquivos na pasta dados
        for (String nomesArquivo : nomesArquivos) {
            arquivo = new File("dados/" + nomesArquivo);
            arquivo.createNewFile();
        }
    }
    public static ArrayList leArquivo(String nomeArquivo) throws FileNotFoundException, IOException{
        ArrayList<String> dados = new ArrayList<String>();
        File arquivo = new File ("dados/" + nomeArquivo + ".txt");
        FileReader ler = new FileReader(arquivo);
        BufferedReader lerb = new BufferedReader(ler);
        String linha = lerb.readLine();
        while(linha!= null){
            dados.add(linha);
            linha = lerb.readLine();
        }
        return dados;
    }
    public static void escreverArquivo(String nomeArquivo, ArrayList lista) throws IOException{
        FileWriter arq = new FileWriter("dados/" + nomeArquivo + ".txt");
        PrintWriter gravarArq = new PrintWriter(arq);
        for(int i = 0; i < lista.size(); i++){
            gravarArq.println(lista.get(i));
        }
        gravarArq.close();
    }
}
