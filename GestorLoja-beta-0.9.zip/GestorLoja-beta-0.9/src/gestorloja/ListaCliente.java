/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestorloja;
import java.util.ArrayList;

/**
 *
 * @author vinic
 */
public class ListaCliente {
     //referencia aos objetos associados
    private static final ArrayList<Cliente> clientes = new ArrayList<>();

    public static int pesquisarPosicaoClientePeloCpf(String cpf){
        
        int i;
        
        for (i=0; i<=clientes.size();i++){
            
            if(i==clientes.size()){
                return -1;
            }    
            if (clientes.get(i).getCpf().equals(cpf)){
                break;
            }
        }
        return i;
    }
    
    
    public static boolean pesquisarCliente(String cpf){
        return (pesquisarPosicaoClientePeloCpf(cpf) != -1);
    }
    
    public static String verificarNomeCliente(int posicao){
        return clientes.get(posicao).getNome();
    }
    
    public static String verificarCpfCliente(int posicao){
        return clientes.get(posicao).getCpf();
    }
    
    public static Cliente retornarClienteEspecifico(int posicao){
        return clientes.get(posicao);
    }
   
    public void inserirClientes( Cliente cli ){
        clientes.add(cli);    
    } 
    
    public void removerClientes( Cliente cli ){
        clientes.remove(cli);    
    }
    
    public ArrayList<Cliente> getClientes() {
        return clientes; 
    }
}