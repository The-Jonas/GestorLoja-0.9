/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorloja;

/**
 *
 * @author mikha
 */
public class Verificador {
    public static boolean isInt(String str) {
    try {
        Integer.parseInt(str);
        if(Integer.parseInt(str)>=0){
            return true;
        }
        else{
            return false;
        }
    } catch (Exception e) {
        return false;
    }
    }
    public static boolean isDouble(String str) {
    try {
        Double.parseDouble(str);
        if(Double.parseDouble(str)>=0){
            return true;
        }
        else{
            return false;
        }
    } catch (Exception e) {
        return false;
    }
}
}
