
package gestorloja;

import java.util.ArrayList;


public class Estacionamento {
    
    //Atributos
    
    private int vagasLivres;
    
    //Referência aos objetos associados
    private static final ArrayList<Veiculo> veiculos = new ArrayList<>();
    
    //Construtores

    public Estacionamento() {
    }

    public Estacionamento(int vagasLivres) {
        this.vagasLivres = vagasLivres;
    }

    // Getters e Setters


    public int getVagasLivres() {
        return vagasLivres;
    }

    public void setVagasLivres(int vagasLivres) {
        this.vagasLivres = vagasLivres;
    }

    public ArrayList<Veiculo> getVeiculos() {
        return veiculos;
    }
    
    public void inserirVeiculo(Veiculo vei){
        veiculos.add(vei);
    }
    
    public void removerVeiculo(Veiculo vei){
        veiculos.remove(vei); 
    }
    
        public ArrayList<Veiculo> retornarVeiculosEstacionados(){
        return veiculos;
    }
    
    //Metodos
    
    public double CalculaOValorAPagar(){
        double pagar = 0;
        
        return pagar;
    }

       
}
