package gestorloja;

import static gestorloja.SalvarDados.escreverArquivo;
import static gestorloja.SalvarDados.leArquivo;
import java.io.IOException;
import java.util.ArrayList;

public class Estoque {
    private static final ArrayList<Item> produtos = new ArrayList<Item>();
    
    public static void adicionarItem(int id, String nome, double preco){
        Item produto = new Item(id, nome, preco);
        produtos.add(produto);  
    }
    public static void removerItem(int id){
        produtos.remove(pesquisarPosicaoItem(id));
    }
    
    public static int pesquisarPosicaoItem(int id){
        int i ;
        for(i = 0; i<= produtos.size(); i++){
            if(i == produtos.size()){
                return -1;
            }
            if ((produtos.get(i)).getIdItem() == id){
                break;
            }
        }
        return i;
    }
    public static boolean pesquisarItem(int id){
        return (pesquisarPosicaoItem(id) != -1);
    }
    public static double verificarPreco(int id){
        int posicao = Estoque.pesquisarPosicaoItem(id);
        return (produtos.get(posicao)).getPrecoItem();
    }
    public static String verificarNome(int id){
        int posicao = Estoque.pesquisarPosicaoItem(id);
        return (produtos.get(posicao)).getNomeItem();
    }
    public static void salvarDadosProdutos() throws IOException{
       ArrayList<String> saida = new ArrayList<String>();
        for(int i = 0; i<produtos.size(); i++){
            saida.add(((produtos.get(i)).getIdItem() + ";" +  (produtos.get(i)).getNomeItem() + ";" + (produtos.get(i)).getPrecoItem()));
        }
        escreverArquivo("produtos", saida);
    }
    public static ArrayList getProdutos(){
        return produtos;
    }
    public static void leDadosProdutos() throws IOException{
        ArrayList<String> saida = leArquivo("produtos");
        for (int i = 0; i<saida.size(); i++){
            String str[] = saida.get(i).split(";");
            Item produto = new Item(Integer.parseInt(str[0]), str[1], Double.parseDouble(str[2]));
            produtos.add(produto);  
        }
    }
}
